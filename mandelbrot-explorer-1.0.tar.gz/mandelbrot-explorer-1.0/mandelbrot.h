#include <gtk/gtk.h>
#include "struct.h"

void mandelbrot(guchar* pix,point* co, int a,int b,int c, OverallState* s);
