

palette parse(char* a);
palette* load_palettes();
