#include "struct.h"

int gui_run (int *argc, char ***argv, OverallState* os);
