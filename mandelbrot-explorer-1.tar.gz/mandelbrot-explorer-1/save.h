#include <gtk/gtk.h>

gboolean on_save(GtkMenuItem *item, OverallState* os);

